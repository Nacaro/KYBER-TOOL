# KYBER TOOL
GitHub Pages build.

- `index.html` — app
- `data/live-data.json` — static Sandcrawler deal snapshot
- `data/game-data.json` — central game-data layer
- `scripts/update_live_data.py` — server-side updater
- `.github/workflows/update-live-data.yml` — hourly GitHub Action
- `assets/droids/` — clean verified artwork

The accepted Stellar/Mythic/Kyber and World Mission timer logic remains locked.
